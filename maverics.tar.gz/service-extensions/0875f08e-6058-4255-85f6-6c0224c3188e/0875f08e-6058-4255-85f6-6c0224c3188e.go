package main

import (
	"fmt"
	"net/http"

	"github.com/strata-io/service-extension/orchestrator"
)

func CreateHeader(api orchestrator.Orchestrator, _ http.ResponseWriter, _ *http.Request) (http.Header, error) {
	logger := api.Logger()
	logger.Debug("se", "building custom header")
	
	session, err := api.Session()
	if err != nil {
		logger.Error("se", "unable to retrieve session", "error", err.Error())
		return nil, err
	}

	firstName, err := session.GetString("azure.givenname")
	if err != nil {
        return nil, fmt.Errorf("unable to retrieve attribute 'azure.givenname': %w", err)
	}
	surname, err := session.GetString("azure.surname")
	if err != nil {
		return nil, fmt.Errorf("unable to retrieve attribute 'azure.givenname': %w", err)
	}
	preferredName := fmt.Sprintf("%s 'The Great' %s", firstName, surname)
	
	return http.Header{"preferredName": []string{preferredName}}, nil
}