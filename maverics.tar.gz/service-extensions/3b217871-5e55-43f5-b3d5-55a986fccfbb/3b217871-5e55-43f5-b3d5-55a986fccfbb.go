package main

import (
	"net/http"
	"time"

	"github.com/strata-io/service-extension/orchestrator"
)

func ModifyRequest(api orchestrator.Orchestrator, req *http.Request) {
	api.Logger().Debug("se", "setting header on request")
	req.Header.Set("X-Req-Time", time.Now().String())
}