package main

import (
	"fmt"
	"net/http"

	"github.com/strata-io/service-extension/orchestrator"
)

func HandleUnauthorized(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
    api.Logger().Debug("msg", "handling unauthorized request")

    http.Error(
        rw,
        fmt.Sprintf(
            "Access denied to %s. Please contact support@example.com for help.",
            req.URL.Path,
        ),
        http.StatusUnauthorized,
    )
}