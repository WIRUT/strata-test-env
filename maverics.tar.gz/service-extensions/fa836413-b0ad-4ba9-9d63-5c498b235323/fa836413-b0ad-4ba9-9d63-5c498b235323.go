package main

import (
	"net/http"
	"strings"

	"github.com/strata-io/service-extension/orchestrator"
)

func IsAuthorized(api orchestrator.Orchestrator, _ http.ResponseWriter, _ *http.Request) bool {
	var (
		logger  = api.Logger()
	)
	session, err := api.Session()
	if err != nil {
		logger.Error("se", "unable to retrieve session", "error", err.Error())
		return false
	}
	logger.Debug("se", "determining if user is authorized")

	rawGroups, _ := session.GetString("azure.groups")
	groups := strings.Split(rawGroups, ",")
	for _, group := range groups {
		if group == "executives" {
			return true
        }
    }

	return false
}